package Model;

import Controller.Commands;

import java.util.ArrayList;

public class User {

    private final static ArrayList<String> allUsernames = new ArrayList<String>();
    private final static ArrayList<User> allUsers = new ArrayList<User>();

    public static ArrayList<String> getAllUsernames() {
        return allUsernames;
    }

    public static ArrayList<User> getAllUsers() {
        return allUsers;
    }
    public static void addUsername(String un) {
        allUsernames.add(un);
    }

    public static void addUser(User user) {
        allUsers.add(user);
    }

    protected String username , password;
    public boolean checkPass(String pass) {
        return pass.equals(this.password);
    }
    public String getUsername() {
        return username;
    }

    public void setPassword(String newPass) {
        this.password = newPass;
    }

    public static void removeAccount(User user) {
        allUsers.remove(user);
        allUsernames.remove(user.username);
        if (user instanceof BossOfRestaurant) {
            BossOfRestaurant.getUsernames().remove(user.username);
            BossOfRestaurant.getBosses().remove(user);
        } else if (user instanceof Customer) {
            Customer.getCustomers().remove(user);
            Customer.getUsernames().remove(user.username);
        }
    }


}
