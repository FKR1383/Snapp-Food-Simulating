package Model;

public class Food {
    private String name , category , restaurant;
    private int price , cost;

    public String getName() {
        return name;
    }

    public String getCategory() {
        return category;
    }

    public int getPrice() {
        return price;
    }

    public int getCost() {
        return cost;
    }

    public Food(String name, String category, int price, int cost, String restaurant) {
        this.name = name;
        this.category = category;
        this.price = price;
        this.cost = cost;
        this.restaurant = restaurant;
        BossOfRestaurant boss = BossOfRestaurant.getBosses().get(BossOfRestaurant.getUsernames().indexOf(restaurant));
        boss.addToMenu(this);
    }
}
