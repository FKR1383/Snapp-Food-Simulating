package Model;

import java.util.ArrayList;

public class Customer extends User{

    private final static ArrayList<String> usernames = new ArrayList<String>();
    private final static ArrayList<Customer> customers = new ArrayList<Customer>();
    private final ArrayList<Discount> myDiscounts = new ArrayList<Discount>();

    private final ArrayList<Order> cart = new ArrayList<Order>();

    public ArrayList<Order> getCart() {
        return cart;
    }

    public void deleteCart() {
        cart.removeAll(cart);
    }

    private int balance;

    public int getBalance() {
        return balance;
    }

    public void charge(int amount) {
        this.balance += amount;
    }

    public ArrayList<Discount> getMyDiscounts() {
        return myDiscounts;
    }

    public Customer(String username, String password) {
        this.username = username;
        this.password = password;
        usernames.add(username);
        customers.add(this);
        User.addUsername(username);
        User.addUser(this);
    }

    public static ArrayList<String> getUsernames() {
        return usernames;
    }

    public static ArrayList<Customer> getCustomers() {
        return customers;
    }

}
