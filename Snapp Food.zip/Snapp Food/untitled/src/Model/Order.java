package Model;

public class Order {
    private String restaurantName;
    private Food food;
    private int number;

    public String getRestaurantName() {
        return restaurantName;
    }

    public Food getFood() {
        return food;
    }

    public int getNumber() {
        return number;
    }
    public void changeNumber(int num) {
        this.number += num;
    }

    public Order(String restaurantName, Food food, int number) {
        this.restaurantName = restaurantName;
        this.food = food;
        this.number = number;
    }
}
