package Model;

import java.util.ArrayList;

public class OwnerOfSnappFood extends User{

    private static final ArrayList<Discount> discounts = new ArrayList<Discount>();
    private static OwnerOfSnappFood owner;
    private OwnerOfSnappFood() {}
    public static OwnerOfSnappFood getOwner() {
        if (owner == null)
            owner = new OwnerOfSnappFood();
        return owner;
    }
    public void setUsername(String username) {
        owner.username = username;
        User.addUsername(username);
        User.addUser(this);
    }

    public static ArrayList<Discount> getDiscounts(){
        return discounts;
    }


    public void setPassword(String password) {
        owner.password = password;
    }

    public boolean checkIsOwner(String username , String password) {
        if (username.equals(OwnerOfSnappFood.getOwner().username) && password.equals(OwnerOfSnappFood.getOwner().password))
            return true;
        return false;
    }

}
