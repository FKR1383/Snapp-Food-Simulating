package Model;

public class Discount {
    private String username , code;
    private int amount;

    public Discount(String username, String code, int amount) {
        this.username = username;
        this.code = code;
        this.amount = amount;
        OwnerOfSnappFood.getDiscounts().add(this);
        Customer.getCustomers().get(Customer.getUsernames().indexOf(username)).getMyDiscounts().add(this);
    }

    public String getUsername() {
        return username;
    }

    public String getCode() {
        return code;
    }

    public int getAmount() {
        return amount;
    }
}
