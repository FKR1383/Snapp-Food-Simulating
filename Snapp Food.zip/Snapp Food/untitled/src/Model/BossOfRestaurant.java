package Model;

import java.util.ArrayList;

public class BossOfRestaurant extends User{
    private String type;
    private int balance;

    public String getType() {
        return type;
    }

    public int getBalance() {
        return balance;
    }

    public void charge(int amount) {
        this.balance += amount;
    }

    private ArrayList<Food> menu = new ArrayList<Food>();
    private ArrayList<String> menuNames = new ArrayList<String>();

    public void addToMenu(Food food) {
        menu.add(food);
        menuNames.add(food.getName());
    }

    public ArrayList<Food> getMenu() {
        return menu;
    }

    public ArrayList<String> getMenuNames() {
        return menuNames;
    }

    public BossOfRestaurant(String username , String password , String type) {
        this.username = username;
        this.password = password;
        this.type = type;
        this.balance = 0;
        User.addUsername(this.username);
        User.addUser(this);
        bosses.add(this);
        usernames.add(this.username);
    }

    private final static ArrayList<String> usernames = new ArrayList<String>();
    private final static ArrayList<BossOfRestaurant> bosses = new ArrayList<BossOfRestaurant>();
    public static ArrayList<String> getUsernames() {
        return usernames;
    }

    public static ArrayList<BossOfRestaurant> getBosses() {
        return bosses;
    }
}
