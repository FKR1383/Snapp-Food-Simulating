import Controller.Controller;
import Model.OwnerOfSnappFood;
import View.Menu.LoginMenu;

import java.util.Scanner;

public class Main {
    static Scanner mainScanner = new Scanner(System.in);
    static void createOwnerOfSnappFood(Scanner scanner) {
        String username , password;
        username = scanner.nextLine();
        password = scanner.nextLine();
        // getting user and pass of Owner of Snapp Food
        OwnerOfSnappFood.getOwner().setUsername(username);
        OwnerOfSnappFood.getOwner().setPassword(password);
    }
    public static void main(String[] args) {
        createOwnerOfSnappFood(mainScanner);
        Controller mainControl = new Controller(mainScanner);
        mainControl.run();
    }
}
