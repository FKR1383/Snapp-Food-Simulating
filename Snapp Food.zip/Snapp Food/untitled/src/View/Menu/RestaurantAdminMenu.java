package View.Menu;

import Controller.Controller;
import Model.BossOfRestaurant;
import Model.Food;
import Model.User;
import Controller.Commands;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RestaurantAdminMenu {
    private User currentUser;
    private final static Scanner mainScanner = Controller.scanner;
    private Controller controller;

    public RestaurantAdminMenu(Controller controller) {
        this.controller = controller;
        this.currentUser = controller.getUser();
    }

    public void run() {
        String command = mainScanner.nextLine();
        Matcher showMenuMatcher = Commands.getMatcher(command , Commands.showMenuRegex);
        Matcher chargeAccountMatcher = Commands.getMatcher(command , Commands.chargeAccountRegex);
        Matcher showBalanceMatcher = Commands.getMatcher(command , Commands.showBalanceRegex);
        Matcher addFoodMatcher = Commands.getMatcher(command , Commands.addFoodRegex);
        Matcher removeFoodMatcher = Commands.getMatcher(command , Commands.removeFood);
        while (true) {
            if (showMenuMatcher.matches()) {
                System.out.println(controller.showMenu());
            } else if (chargeAccountMatcher.matches()) {
                System.out.println(controller.chargeAccount(chargeAccountMatcher));
            } else if (showBalanceMatcher.matches()) {
                System.out.println(controller.showBalance());
            } else if (addFoodMatcher.matches()) {
                System.out.println(controller.addFood(addFoodMatcher));
            } else if (removeFoodMatcher.matches()) {
                String res = controller.removeFood(removeFoodMatcher);
                if (!res.equals(""))
                    System.out.println(res);
            }  else if (command.matches("[\\s]*logout[\\s]*")) {
                controller.setCurrentMenu("login menu");
                break;
            } else {
                System.out.println("invalid command!");
            }
            command = mainScanner.nextLine();
            showMenuMatcher = Commands.getMatcher(command , Commands.showMenuRegex);
            chargeAccountMatcher = Commands.getMatcher(command , Commands.chargeAccountRegex);
            showBalanceMatcher = Commands.getMatcher(command , Commands.showBalanceRegex);
            addFoodMatcher = Commands.getMatcher(command , Commands.addFoodRegex);
            removeFoodMatcher = Commands.getMatcher(command , Commands.removeFood);
        }
    }


}
