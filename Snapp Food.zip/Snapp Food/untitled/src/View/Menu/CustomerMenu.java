package View.Menu;

import Controller.Controller;
import Model.*;
import Controller.Commands;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;

public class CustomerMenu {
    private User currentUser;
    private final static Scanner mainScanner = Controller.scanner;
    private Controller controller;

    public CustomerMenu(Controller controller) {
        this.controller = controller;
        this.currentUser = controller.getUser();
    }

    public void run() {
        String command = mainScanner.nextLine();
        Matcher showMenuMatcher = Commands.getMatcher(command , Commands.showMenuRegex);
        Matcher chargeAccountMatcher = Commands.getMatcher(command , Commands.chargeAccountRegex);
        Matcher showBalanceMatcher = Commands.getMatcher(command , Commands.showBalanceRegex);
        Matcher showRestaurantMatcher = Commands.getMatcher(command , Commands.showRestaurantRegex);
        Matcher showRestaurantMenuRegex = Commands.getMatcher(command , Commands.showRestaurantMenuRegex);
        Matcher addToCartMatcher = Commands.getMatcher(command , Commands.addToCartRegex);
        Matcher removeFromCartMatcher = Commands.getMatcher(command , Commands.removeFromCartRegex);
        Matcher showCartMatcher = Commands.getMatcher(command , Commands.showCartRegex);
        Matcher showDiscountsMatcher = Commands.getMatcher(command , Commands.showDiscounts);
        Matcher purchaseMatcher = Commands.getMatcher(command , Commands.purchaseRegex);
        while (true) {
            if (showMenuMatcher.matches()) {
                System.out.println(controller.showMenu());
            } else if (chargeAccountMatcher.matches()) {
                System.out.println(controller.chargeAccount(chargeAccountMatcher));
            } else if (showBalanceMatcher.matches()) {
                System.out.println(controller.showBalance());
            } else if (showRestaurantMatcher.matches()) {
                String res = controller.showRestaurant(showRestaurantMatcher);
                if (!res.equals(""))
                    System.out.println(res);
            } else if (showRestaurantMenuRegex.matches()) {
                String res = controller.showRestaurantMenu(showRestaurantMenuRegex);
                if (!res.equals(""))
                    System.out.println(res);
            } else if (addToCartMatcher.matches()) {
                System.out.println(controller.addToCart(addToCartMatcher));
            } else if (removeFromCartMatcher.matches()) {
                System.out.println(controller.removeFromCart(removeFromCartMatcher));
            } else if (showCartMatcher.matches()) {
                System.out.println(controller.showCart());
            } else if (showDiscountsMatcher.matches()) {
                String result = controller.showDiscounts();
                if (!result.equals(""))
                    System.out.println(result);
            } else if (purchaseMatcher.matches()) {
                System.out.println(controller.purchase(purchaseMatcher));
            }   else if (command.matches("[\\s]*logout[\\s]*")) {
                controller.setCurrentMenu("login menu");
                break;
            } else {
                System.out.println("invalid command!");
            }
            command = mainScanner.nextLine();
            showMenuMatcher = Commands.getMatcher(command , Commands.showMenuRegex);
            chargeAccountMatcher = Commands.getMatcher(command , Commands.chargeAccountRegex);
            showBalanceMatcher = Commands.getMatcher(command , Commands.showBalanceRegex);
            showRestaurantMatcher = Commands.getMatcher(command , Commands.showRestaurantRegex);
            showRestaurantMenuRegex = Commands.getMatcher(command , Commands.showRestaurantMenuRegex);
            addToCartMatcher = Commands.getMatcher(command , Commands.addToCartRegex);
            removeFromCartMatcher = Commands.getMatcher(command , Commands.removeFromCartRegex);
            showCartMatcher = Commands.getMatcher(command , Commands.showCartRegex);
            showDiscountsMatcher = Commands.getMatcher(command , Commands.showDiscounts);
            purchaseMatcher = Commands.getMatcher(command , Commands.purchaseRegex);
        }
    }


}
