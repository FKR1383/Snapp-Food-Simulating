package View.Menu;

import Controller.Controller;
import Controller.Commands;
import Model.BossOfRestaurant;
import Model.Customer;
import Model.OwnerOfSnappFood;
import Model.User;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainMenu {
    private boolean mainMenuRunning = true;

    private User currentUser;
    private final static Scanner mainScanner = Controller.scanner;
    private Controller controller;
    private String nextMenu;

    public void setMainMenuRunning(boolean mainMenuRunning) {
        this.mainMenuRunning = mainMenuRunning;
    }

    public void setNextMenu(String nextMenu) {
        this.nextMenu = nextMenu;
    }

    public boolean isMainMenuRunning() {
        return mainMenuRunning;
    }

    public String getNextMenu() {
        return nextMenu;
    }

    public MainMenu(Controller controller) {
        this.controller = controller;
    }

    public void run() {
        mainMenuRunning = false;
        currentUser = controller.getUser();
        String command = mainScanner.nextLine();
        Matcher showMenuMatcher = Commands.getMatcher(command , Commands.showMenuRegex);
        Matcher enterMenuMatcher = Commands.getMatcher(command , Commands.enterMenuRegex);
        while (true) {
            if (showMenuMatcher.matches()) {
                System.out.println(controller.showMenu());
            } else if (enterMenuMatcher.matches()) {
                System.out.println(controller.enterMenu(enterMenuMatcher));
                if (mainMenuRunning) {
                    controller.setCurrentMenu(nextMenu);
                    break;
                }
            } else if (command.matches("[\\s]*logout[\\s]*")) {
                controller.setCurrentMenu("login menu");
                break;
            } else {
                System.out.println("invalid command!");
            }
            command = mainScanner.nextLine();
            showMenuMatcher = Commands.getMatcher(command , Commands.showMenuRegex);
            enterMenuMatcher = Commands.getMatcher(command , Commands.enterMenuRegex);
        }
    }
}
