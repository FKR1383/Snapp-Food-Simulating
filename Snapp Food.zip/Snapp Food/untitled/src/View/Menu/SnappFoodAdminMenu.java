package View.Menu;

import Controller.Controller;
import Model.*;
import Controller.Commands;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SnappFoodAdminMenu {

    private User currentUser;
    private final static Scanner mainScanner = Controller.scanner;
    private Controller controller;

    public SnappFoodAdminMenu(Controller controller) {
        this.controller = controller;
        this.currentUser = controller.getUser();
    }

    public void run() {
        String command = mainScanner.nextLine();
        Matcher showMenuMatcher = Commands.getMatcher(command , Commands.showMenuRegex);
        Matcher addRestaurantMatcher = Commands.getMatcher(command , Commands.addRestaurantRegex);
        Matcher showRestaurantMatcher = Commands.getMatcher(command , Commands.showRestaurantRegex);
        Matcher removeRestaurantMatcher = Commands.getMatcher(command , Commands.removeRestaurantRegex);
        Matcher setDiscountMatcher = Commands.getMatcher(command , Commands.setDiscountRegex);
        Matcher showDiscountsMatcher = Commands.getMatcher(command , Commands.showDiscounts);
        while (true) {
            if (showMenuMatcher.matches()) {
                System.out.println(controller.showMenu());
            } else if (addRestaurantMatcher.matches()) {
                System.out.println(controller.addRestaurant(addRestaurantMatcher));
            } else if (showRestaurantMatcher.matches()) {
                String res = controller.showRestaurantForOwner(showRestaurantMatcher);
                if (!res.equals("")) {
                    System.out.println(res);
                }
            } else if (removeRestaurantMatcher.matches()) {
                String res = controller.removeRestaurant(removeRestaurantMatcher);
                if (!res.equals("")) {
                    System.out.println(res);
                }
            } else if (setDiscountMatcher.matches()) {
                System.out.println(controller.setDiscount(setDiscountMatcher));
            } else if (showDiscountsMatcher.matches()) {
                String res = controller.showDiscountsForOwner();
                if (!res.equals("")) {
                    System.out.println(res);
                }
            } else if (command.matches("[\\s]*logout[\\s]*")) {
                controller.setCurrentMenu("login menu");
                break;
            } else {
                System.out.println("invalid command!");
            }
            command = mainScanner.nextLine();
            showMenuMatcher = Commands.getMatcher(command , Commands.showMenuRegex);
            addRestaurantMatcher = Commands.getMatcher(command , Commands.addRestaurantRegex);
            showRestaurantMatcher = Commands.getMatcher(command , Commands.showRestaurantRegex);
            removeRestaurantMatcher = Commands.getMatcher(command , Commands.removeRestaurantRegex);
            setDiscountMatcher = Commands.getMatcher(command , Commands.setDiscountRegex);
            showDiscountsMatcher = Commands.getMatcher(command , Commands.showDiscounts);
        }
    }

}
