package View.Menu;

import Controller.Commands;
import Controller.Controller;
import Model.BossOfRestaurant;
import Model.Customer;
import Model.OwnerOfSnappFood;
import Model.User;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LoginMenu {
    private final static Scanner loginScanner = Controller.scanner;
    private Controller controller;

    public LoginMenu(Controller controller) {
        this.controller = controller;
    }

    public void run() {
        String command = loginScanner.nextLine();
        Matcher showMenuMatcher = Commands.getMatcher(command , Commands.showMenuRegex);
        Matcher registerMatcher = Commands.getMatcher(command , Commands.registerRegex);
        Matcher loginMatcher = Commands.getMatcher(command , Commands.loginRegex);
        Matcher changePassMatcher = Commands.getMatcher(command , Commands.changePasswordRegex);
        Matcher removeAccountMatcher = Commands.getMatcher(command , Commands.removeAccountRegex);
        while (!controller.ending_program) {
            if (showMenuMatcher.matches()) {
                System.out.println(controller.showMenu());
            } else if (registerMatcher.matches()) {
                System.out.println(controller.register(registerMatcher));
            } else if (loginMatcher.matches()) {
                System.out.println(controller.login(loginMatcher));
            } else if (changePassMatcher.matches()) {
                System.out.println(controller.changePassword(changePassMatcher));
            } else if (removeAccountMatcher.matches()) {
                System.out.println(controller.removeAccount(removeAccountMatcher));
            } else if (command.matches("[\\s]*exit[\\s]*")) {
                controller.ending_program = true;
                break;
            } else {
                System.out.println("invalid command!");
            }
            if (!controller.getCurrentMenu().equals("login menu"))
                break;
            command = loginScanner.nextLine();
            showMenuMatcher = Commands.getMatcher(command , Commands.showMenuRegex);
            registerMatcher = Commands.getMatcher(command , Commands.registerRegex);
            loginMatcher = Commands.getMatcher(command , Commands.loginRegex);
            changePassMatcher = Commands.getMatcher(command , Commands.changePasswordRegex);
            removeAccountMatcher = Commands.getMatcher(command , Commands.removeAccountRegex);
        }
    }
}
