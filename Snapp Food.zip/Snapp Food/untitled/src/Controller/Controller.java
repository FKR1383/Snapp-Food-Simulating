package Controller;

import Model.*;
import View.Menu.*;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Controller {
    private User user;
    private OwnerOfSnappFood owner;
    private BossOfRestaurant boss;
    private Customer customer;

    public User getUser() {
        return user;
    }

    public OwnerOfSnappFood getOwner() {
        return owner;
    }

    public BossOfRestaurant getBoss() {
        return boss;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public void setOwner(OwnerOfSnappFood owner) {
        this.owner = owner;
    }

    public void setBoss(BossOfRestaurant boss) {
        this.boss = boss;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public String currentMenu = "login menu";
    public boolean ending_program = false;
    private final LoginMenu loginMenu;
    public static Scanner scanner;
    private final MainMenu mainMenu;
    private final CustomerMenu customerMenu;
    private final RestaurantAdminMenu resAdmin;
    private final SnappFoodAdminMenu snappOwner;

    public Controller(Scanner scan) {
        scanner = scan;
        loginMenu = new LoginMenu(this);
        mainMenu = new MainMenu(this);
        customerMenu = new CustomerMenu(this);
        resAdmin = new RestaurantAdminMenu(this);
        snappOwner = new SnappFoodAdminMenu(this);
    }

    public void setCurrentMenu(String currentMenu) {
        this.currentMenu = currentMenu;
    }

    public String getCurrentMenu() {
        return currentMenu;
    }

    public void run() {
        while (!ending_program) {
            switch(currentMenu) {
                case "login menu" : {
                    loginMenu.run();
                } break;
                case "main menu" : {
                    mainMenu.run();
                } break;
                case "Snappfood admin menu" : {
                    snappOwner.run();
                } break;
                case "restaurant admin menu" : {
                    resAdmin.run();
                } break;
                case "customer menu" : {
                    customerMenu.run();
                } break;
            }
        }
    }

    public String showMenu() {
        return this.getCurrentMenu();
    }


    public int showBalance() {
        if (user instanceof Customer)
            return this.getCustomer().getBalance();
        else if (user instanceof BossOfRestaurant)
            return this.getBoss().getBalance();
        // this state doesn't exist.
        return -1;
    }

    public String showRestaurant(Matcher matcher) {
        String result = "";
        String type = matcher.group("type");
        int index = 0;
        if (type != null) {
            for (BossOfRestaurant i : BossOfRestaurant.getBosses()) {
                if (i.getType().equals(type)) {
                    if (index == 0) {
                        result += (++index) + ") " + i.getUsername() + ": type=" + i.getType();
                    } else {
                        result += "\n" + (++index) + ") " + i.getUsername() + ": type=" + i.getType();
                    }
                }
            }
        } else {
            for (BossOfRestaurant i : BossOfRestaurant.getBosses()) {
                if (index == 0) {
                    result += (++index) + ") " + i.getUsername() + ": type=" + i.getType();
                } else {
                    result += "\n" + (++index) + ") " + i.getUsername() + ": type=" + i.getType();
                }
            }
        }
        return result;
    }

    public String showRestaurantMenu(Matcher matcher) {
        String name = matcher.group("name");
        String category = matcher.group("category");
        ArrayList<Food> starters = new ArrayList<Food>();
        ArrayList<Food> entrees = new ArrayList<Food>();
        ArrayList<Food> desserts = new ArrayList<Food>();
        if (!BossOfRestaurant.getUsernames().contains(name)) {
            return "show menu failed: restaurant not found";
        }
        if (category != null && !category.equals("starter") && !category.equals("entree") && !category.equals("dessert")) {
            return "show menu failed: invalid category";
        }
        BossOfRestaurant boss = BossOfRestaurant.getBosses().get(BossOfRestaurant.getUsernames().indexOf(name));
        String result = "";
        for (Food i : boss.getMenu()) {
            if (i.getCategory().equals("starter"))
                starters.add(i);
            else if (i.getCategory().equals("entree"))
                entrees.add(i);
            else if (i.getCategory().equals("dessert"))
                desserts.add(i);
        }
        if (category == null) {
            result += "<< STARTER >>";
            for (Food i : starters) {
                result += "\n" + i.getName() + " | price=" + i.getPrice();
            }
            result += "\n<< ENTREE >>";
            for (Food i : entrees) {
                result += "\n" + i.getName() + " | price=" + i.getPrice();
            }
            result += "\n<< DESSERT >>";
            for (Food i : desserts) {
                result += "\n" + i.getName() + " | price=" + i.getPrice();
            }
        } else {
            int index = 0;
            if (category.equals("starter")) {
                for (Food i : starters) {
                    if (index == 0)
                        result += i.getName() + " | price=" + i.getPrice();
                    else
                        result += "\n" + i.getName() + " | price=" + i.getPrice();
                    index++;
                }
            } else if (category.equals("entree")) {
                for (Food i : entrees) {
                    if (index == 0)
                        result += i.getName() + " | price=" + i.getPrice();
                    else
                        result += "\n" + i.getName() + " | price=" + i.getPrice();
                    index++;
                }
            } else if (category.equals("dessert")) {
                for (Food i : desserts) {
                    if (index == 0)
                        result += i.getName() + " | price=" + i.getPrice();
                    else
                        result += "\n" + i.getName() + " | price=" + i.getPrice();
                    index++;
                }
            }
        }
        return result;
    }

    public String addToCart(Matcher matcher) {
        String rname = matcher.group("rname");
        String fname = matcher.group("fname");
        String numberString = matcher.group("number");
        if (!BossOfRestaurant.getUsernames().contains(rname)) {
            return "add to cart failed: restaurant not found";
        }
        BossOfRestaurant boss = BossOfRestaurant.getBosses().get(BossOfRestaurant.getUsernames().indexOf(rname));
        if (!boss.getMenuNames().contains(fname)) {
            return "add to cart failed: food not found";
        }
        int number = 1;
        if (numberString != null) {
            number = Integer.parseInt(numberString);
            if (number <= 0)
                return "add to cart failed: invalid number";
        }
        for (Order i : this.getCustomer().getCart()) {
            if (i.getRestaurantName().equals(rname) && i.getFood().getName().equals(fname)) {
                i.changeNumber(number);
                return "add to cart successful";
            }
        }
        Food food = boss.getMenu().get(boss.getMenuNames().indexOf(fname));
        Order order = new Order(rname , food , number);
        this.getCustomer().getCart().add(order);
        return "add to cart successful";
    }

    public String removeFromCart(Matcher matcher) {
        String rname = matcher.group("rname");
        String fname = matcher.group("fname");
        String numberString = matcher.group("number");
        int number = 1;
        if (numberString != null)
            number = Integer.parseInt(numberString);
        for (Order i : this.getCustomer().getCart()) {
            if (i.getRestaurantName().equals(rname) && i.getFood().getName().equals(fname)) {
                if (number <= 0) {
                    return "remove from cart failed: invalid number";
                }
                if (number > i.getNumber()) {
                    return "remove from cart failed: not enough food in cart";
                }
                if (number == i.getNumber()) {
                    this.getCustomer().getCart().remove(i);
                } else {
                    i.changeNumber(-number);
                }
                return "remove from cart successful";
            }
        }
        return "remove from cart failed: not in cart";
    }

    public String showCart() {
        String result = "";
        int index = 0 , totalPrice = 0;
        for (Order i : this.getCustomer().getCart()) {
            totalPrice += i.getNumber() * i.getFood().getPrice();
            if (index == 0) {
                result += (++index) + ") " + i.getFood().getName() + " | restaurant=" + i.getRestaurantName() + " price=" + i.getNumber()*i.getFood().getPrice();
            } else {
                result += "\n" + (++index) + ") " + i.getFood().getName() + " | restaurant=" + i.getRestaurantName() + " price=" + i.getNumber()*i.getFood().getPrice();
            }
        }
        if (index != 0)
            result += "\nTotal: " + totalPrice;
        else
            result += "Total: " + totalPrice;
        return result;
    }

    public String showDiscounts() {
        String result = "";
        int index = 0;
        for (Discount i : this.getCustomer().getMyDiscounts()) {
            if (index == 0) {
                result += (++index) + ") " + i.getCode() + " | amount=" + i.getAmount();
            } else {
                result += "\n" + (++index) + ") " + i.getCode() + " | amount=" + i.getAmount();
            }
        }
        return result;
    }

    public String purchase(Matcher matcher) {
        String code = matcher.group("code");
        Discount dis = null;
        int priceCustomer = 0 , priceRes = 0 , costRes = 0;
        if (code != null) {
            for (Discount i : this.getCustomer().getMyDiscounts()) {
                if (i.getCode().equals(code)) {
                    dis = i;
                    break;
                }
            }
            if (dis == null) {
                return "purchase failed: invalid discount code";
            }
        }
        for (Order i : this.getCustomer().getCart()) {
            priceCustomer += i.getNumber() * i.getFood().getPrice();
        }
        if (dis != null) {
            priceCustomer -= dis.getAmount();
        }
        if (priceCustomer > this.getCustomer().getBalance()) {
            return "purchase failed: inadequate money";
        }
        if (dis != null) {
            this.getCustomer().getMyDiscounts().remove(dis);
        }
        this.getCustomer().charge(-priceCustomer);
        for (Order i : this.getCustomer().getCart()) {
            BossOfRestaurant boss = BossOfRestaurant.getBosses().get(BossOfRestaurant.getUsernames().indexOf(i.getRestaurantName()));
            boss.charge(i.getNumber()*(i.getFood().getPrice()-i.getFood().getCost()));
        }
        this.getCustomer().deleteCart();
        return "purchase successful";
    }

    public String register(Matcher matcher) {
        String username , password;
        username = matcher.group("username");
        password = matcher.group("password");
        if (!validUsername(username))
            return "register failed: invalid username format";
        if (User.getAllUsernames().contains(username))
            return "register failed: username already exists";
        if (!validPassword(password)) {
            return "register failed: invalid password format";
        }
        if (!isPasswordStrong(password)) {
            return "register failed: weak password";
        }
        Customer newCustomer = new Customer(username , password);
        return "register successful";
    }

    private static boolean validUsername(String test) {
        String regex = "[a-zA-Z0-9_]+";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(test);
        String regex2 = "[a-zA-Z]";
        Pattern pattern2 = Pattern.compile(regex2);
        Matcher matcher2 = pattern2.matcher(test);
        if (!matcher.matches() || !matcher2.find()) {
            return false;
        }
        return true;
    }

    private static boolean validPassword(String test) {
        String regex = "[a-zA-Z0-9_]+";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(test);
        if (!matcher.matches()) {
            return false;
        }
        return true;
    }

    private static boolean isPasswordStrong(String pass) {
        if (pass.length() < 5) {
            return false;
        }
        String regex1 = "[a-z]";
        String regex2 = "[A-Z]";
        String regex3 = "[0-9]";
        Pattern pattern1 = Pattern.compile(regex1);
        Pattern pattern2 = Pattern.compile(regex2);
        Pattern pattern3 = Pattern.compile(regex3);
        Matcher matcher1 = pattern1.matcher(pass);
        Matcher matcher2 = pattern2.matcher(pass);
        Matcher matcher3 = pattern3.matcher(pass);
        if (!matcher1.find() || !matcher2.find() || !matcher3.find()) {
            return false;
        }
        return true;
    }

    public String login(Matcher matcher) {
        String username = matcher.group("username");
        String password = matcher.group("password");
        if (!User.getAllUsernames().contains(username)) {
            return "login failed: username not found";
        }
        int index = Customer.getUsernames().indexOf(username);
        int index2 = BossOfRestaurant.getUsernames().indexOf(username);
        if (index != -1) {
            // customer
            if (!Customer.getCustomers().get(index).checkPass(password)) {
                return "login failed: incorrect password";
            }
            this.setUser(Customer.getCustomers().get(index));
            this.setCustomer(Customer.getCustomers().get(index));
        } else if (index2 != -1) {
            // boss of restaurant
            if (!BossOfRestaurant.getBosses().get(index2).checkPass(password)) {
                return "login failed: incorrect password";
            }
            this.setUser(BossOfRestaurant.getBosses().get(index2));
            this.setBoss(BossOfRestaurant.getBosses().get(index2));
        } else {
            // owner of snapp
            if (!OwnerOfSnappFood.getOwner().checkPass(password)) {
                return "login failed: incorrect password";
            }
            this.setOwner(OwnerOfSnappFood.getOwner());
            this.setUser(OwnerOfSnappFood.getOwner());
        }
        this.setCurrentMenu("main menu");
        return "login successful";
    }

    public String changePassword(Matcher matcher){
        String username , oldPass , newPass;
        username = matcher.group("username");
        oldPass = matcher.group("oldpass");
        newPass = matcher.group("newpass");
        if (!User.getAllUsernames().contains(username)) {
            return "password change failed: username not found";
        }
        int index = User.getAllUsernames().indexOf(username);
        User user = User.getAllUsers().get(index);
        if (!user.checkPass(oldPass)) {
            return "password change failed: incorrect password";
        }
        if (!validPassword(newPass)) {
            return "password change failed: invalid new password";
        }
        if (!isPasswordStrong(newPass)) {
            return "password change failed: weak new password";
        }
        user.setPassword(newPass);
        return "password change successful";
    }

    public String removeAccount(Matcher matcher) {
        String username , password;
        username = matcher.group("username");
        password = matcher.group("password");
        if (!User.getAllUsernames().contains(username)) {
            return "remove account failed: username not found";
        }
        User user = User.getAllUsers().get(User.getAllUsernames().indexOf(username));
        if (!user.checkPass(password)) {
            return "remove account failed: incorrect password";
        }
        User.removeAccount(user);
        return "remove account successful";
    }

    public String enterMenu(Matcher matcher) {
        String menu = matcher.group("menu");
        String regex = "(?<menuname>(customer menu)|(restaurant admin menu)|(Snappfood admin menu))[\\s]*";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher2 = pattern.matcher(menu);
        if (matcher2.matches()) {
            String menuName = matcher2.group("menuname");
            if (menuName.equals("customer menu")) {
                if (user instanceof Customer) {
                    mainMenu.setMainMenuRunning(true);
                    mainMenu.setNextMenu(menuName);
                    return "enter menu successful: You are in the " + menuName + "!";
                }
                return "enter menu failed: access denied";
            } else if (menuName.equals("restaurant admin menu")) {
                if (user instanceof BossOfRestaurant) {
                    mainMenu.setMainMenuRunning(true);
                    mainMenu.setNextMenu(menuName);
                    return "enter menu successful: You are in the " + menuName + "!";
                }
                return "enter menu failed: access denied";
            } else if (menuName.equals("Snappfood admin menu")){
                if (user instanceof OwnerOfSnappFood) {
                    mainMenu.setMainMenuRunning(true);
                    mainMenu.setNextMenu(menuName);
                    return "enter menu successful: You are in the " + menuName + "!";
                }
                return "enter menu failed: access denied";
            }
        }
        return "enter menu failed: invalid menu name";
    }

    public String chargeAccount(Matcher matcher) {
        String amountString = matcher.group("amount");
        int amount = Integer.parseInt(amountString);
        if (amount <= 0) {
            return "charge account failed: invalid cost or price";
        }
        if (user instanceof BossOfRestaurant)
            ((BossOfRestaurant) user).charge(amount);
        else if (user instanceof Customer)
            ((Customer) user).charge(amount);
        return "charge account successful";
    }

    private boolean validCategory(String test) {
        if (test.equals("starter") || test.equals("entree") || test.equals("dessert"))
            return true;
        return false;
    }

    private static boolean validName(String test) {
        String regex = "[a-z\\-]+";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(test);
        if (!matcher.matches()) {
            return false;
        }
        return true;
    }

    public String addFood(Matcher matcher) {
        String name = matcher.group("name");
        String category = matcher.group("category");
        String priceString = matcher.group("price");
        String costString = matcher.group("cost");
        if (!validCategory(category)) {
            return "add food failed: invalid category";
        }
        if (!validName(name)) {
            return "add food failed: invalid food name";
        }
        if (this.getBoss().getMenuNames().contains(name)) {
            return "add food failed: food already exists";
        }
        int price = Integer.parseInt(priceString);
        int cost = Integer.parseInt(costString);
        if (price <= 0 || cost <= 0) {
            return "add food failed: invalid cost or price";
        }
        Food newFood = new Food(name ,category , price , cost , this.getBoss().getUsername());
        return "add food successful";
    }

    public String removeFood(Matcher matcher) {
        String name = matcher.group("name");
        if (!this.getBoss().getMenuNames().contains(name)) {
            return "remove food failed: food not found";
        }
        Food food = this.getBoss().getMenu().get(this.getBoss().getMenuNames().indexOf(name));
        this.getBoss().getMenu().remove(food);
        this.getBoss().getMenuNames().remove(name);
        return "";
    }

    public String addRestaurant(Matcher matcher) {
        String username = matcher.group("name");
        String password = matcher.group("password");
        String type = matcher.group("type");
        if (!validUsername(username))
            return "add restaurant failed: invalid username format";
        if (User.getAllUsernames().contains(username))
            return "add restaurant failed: username already exists";
        if (!validPassword(password)) {
            return "add restaurant failed: invalid password format";
        }
        if (!isPasswordStrong(password)) {
            return "add restaurant failed: weak password";
        }
        if (!validType(type)) {
            return "add restaurant failed: invalid type format";
        }
        BossOfRestaurant boss = new BossOfRestaurant(username , password , type);
        return "add restaurant successful";
    }


    private static boolean validType(String test) {
        String regex = "[a-z\\-]+";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(test);
        if (!matcher.matches()) {
            return false;
        }
        return true;
    }


    public String showRestaurantForOwner(Matcher matcher) {
        String result = "";
        String type = matcher.group("type");
        int index = 0;
        if (type != null) {
            for (BossOfRestaurant i : BossOfRestaurant.getBosses()) {
                if (i.getType().equals(type)) {
                    if (index == 0) {
                        result += (++index) + ") " + i.getUsername() + ": type=" + i.getType() + " balance=" + i.getBalance();
                    } else {
                        result += "\n" + (++index) + ") " + i.getUsername() + ": type=" + i.getType() + " balance=" + i.getBalance();
                    }
                }
            }
        } else {
            for (BossOfRestaurant i : BossOfRestaurant.getBosses()) {
                if (index == 0) {
                    result += (++index) + ") " + i.getUsername() + ": type=" + i.getType() + " balance=" + i.getBalance();
                } else {
                    result += "\n" + (++index) + ") " + i.getUsername() + ": type=" + i.getType() + " balance=" + i.getBalance();
                }
            }
        }
        return result;
    }

    public String removeRestaurant(Matcher matcher) {
        String name = matcher.group("name");
        if (!BossOfRestaurant.getUsernames().contains(name)) {
            return "remove restaurant failed: restaurant not found";
        }
        User boss = BossOfRestaurant.getBosses().get(BossOfRestaurant.getUsernames().indexOf(name));
        User.removeAccount(boss);
        return "";
    }

    private boolean validCode(String test) {
        String regex = "[a-zA-Z0-9]+";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(test);
        if (matcher.matches())
            return true;
        return false;
    }

    public String setDiscount(Matcher matcher) {
        String username = matcher.group("username");
        String amountString = matcher.group("amount");
        String code = matcher.group("code");
        if (!Customer.getUsernames().contains(username)) {
            return "set discount failed: username not found";
        }
        int amount = Integer.parseInt(amountString);
        if (amount <= 0) {
            return "set discount failed: invalid amount";
        }
        if (!validCode(code)) {
            return "set discount failed: invalid code format";
        }
        new Discount(username , code , amount);
        return "set discount successful";
    }

    public String showDiscountsForOwner() {
        int index = 0;
        String result = "";
        for (Discount i : OwnerOfSnappFood.getDiscounts()) {
            if (index == 0) {
                result += (++index) + ") " + i.getCode() + " | amount=" + i.getAmount() + " --> user=" + i.getUsername();
            } else {
                result += "\n" + (++index) + ") " + i.getCode() + " | amount=" + i.getAmount() + " --> user=" + i.getUsername();
            }
        }
        return result;
    }

}
