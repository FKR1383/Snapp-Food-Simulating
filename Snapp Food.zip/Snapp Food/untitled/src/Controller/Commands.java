package Controller;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

// this enum uses for saving all command regexes
// we can use getMatcher method to create a matcher with specified regex
public enum Commands {
    showMenuRegex("[\\s]*show[\\s]+current[\\s]+menu[\\s]*"),
    registerRegex("[\\s]*register[\\s]+(?<username>[\\S]+)[\\s]+(?<password>[\\S]+)[\\s]*"),
    loginRegex("[\\s]*login[\\s]+(?<username>[\\S]+)[\\s]+(?<password>[\\S]+)[\\s]*"),
    changePasswordRegex("[\\s]*change[\\s]+password[\\s]+(?<username>[\\S]+)[\\s]+(?<oldpass>[\\S]+)[\\s]+(?<newpass>[\\S]+)[\\s]*"),
    removeAccountRegex("[\\s]*remove[\\s]+account[\\s]+(?<username>[\\S]+)[\\s]+(?<password>[\\S]+)[\\s]*"),
    enterMenuRegex("[\\s]*enter[\\s]+(?<menu>.+)"),
    addRestaurantRegex("[\\s]*add[\\s]+restaurant[\\s]+(?<name>[\\S]+)[\\s]+(?<password>[\\S]+)[\\s]+(?<type>[\\S]+)[\\s]*"),
    showRestaurantRegex("[\\s]*show[\\s]+restaurant([\\s]+-t[\\s]+(?<type>[\\S]+))?[\\s]*"),
    removeRestaurantRegex("[\\s]*remove[\\s]+restaurant[\\s]+(?<name>[\\S]+)[\\s]*"),
    setDiscountRegex("[\\s]*set[\\s]+discount[\\s]+(?<username>[\\S]+)[\\s]+(?<amount>[+\\-]?[\\d]+)[\\s]+(?<code>[\\S]+)[\\s]*"),
    showDiscounts("[\\s]*show[\\s]+discounts[\\s]*"),
    chargeAccountRegex("[\\s]*charge[\\s]+account[\\s]+(?<amount>[+\\-]?[\\d]+)[\\s]*"),
    showBalanceRegex("[\\s]*show[\\s]+balance[\\s]*"),
    addFoodRegex("[\\s]*add[\\s]+food[\\s]+(?<name>[\\S]+)[\\s]+(?<category>[\\S]+)[\\s]+(?<price>[+\\-]?[\\d]+)[\\s]+(?<cost>[+\\-]?[\\d]+)[\\s]*"),
    removeFood("[\\s]*remove[\\s]+food[\\s]+(?<name>[\\S]+)[\\s]*"),
    showRestaurantMenuRegex("[\\s]*show[\\s]+menu[\\s]+(?<name>[\\S]+)([\\s]+-c[\\s]+(?<category>[\\S]+))?[\\s]*"),
    addToCartRegex("[\\s]*add[\\s]+to[\\s]+cart[\\s]+(?<rname>[\\S]+)[\\s]+(?<fname>[\\S]+)([\\s]+-n[\\s]+(?<number>[+\\-]?[\\d]+))?[\\s]*"),
    removeFromCartRegex("[\\s]*remove[\\s]+from[\\s]+cart[\\s]+(?<rname>[\\S]+)[\\s]+(?<fname>[\\S]+)([\\s]+-n[\\s]+(?<number>[+\\-]?[\\d]+))?[\\s]*"),
    showCartRegex("[\\s]*show[\\s]+cart[\\s]*"),
    purchaseRegex("[\\s]*purchase[\\s]+cart([\\s]+-d[\\s]+(?<code>[\\S]+))?[\\s]*");
    private String regex;
    private Commands(String regex) {
        this.regex = regex;
    }
    public static Matcher getMatcher(String input , Commands command) {
        Pattern pattern = Pattern.compile(command.regex);
        Matcher matcher = pattern.matcher(input);
        return matcher;
    }
}
